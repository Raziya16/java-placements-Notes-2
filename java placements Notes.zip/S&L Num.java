import java.util.Scanner;

public class S&L Num {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr = new int[n];
        for(int i=0;i<n;i++){
            arr[i]=sc.nextInt();
        
        System.out.println("Smallest element: " + smallest);
        System.out.println("Largest element: " + largest);
        sc.close();
    }
}